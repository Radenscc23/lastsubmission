package com.example.githubuser.ui.detail

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.android.material.tabs.TabLayoutMediator
import com.example.githubuser.R
import com.example.githubuser.adapter.SectionPagerAdapter
import com.example.githubuser.database.FavoriteEntity
import com.example.githubuser.databinding.ActivityDetailBinding
import com.example.githubuser.datasource.UserResponse
import com.example.githubuser.networking.NetworkConnection

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private var isFavorite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.detailDataLayout.visibility = View.GONE
        val username = intent.getStringExtra(KEY_USERNAME)
        username?.let{
            showLoading(true) // Show progress bar initially
            checkInternetConnection(it)
        }
    }

    private fun checkInternetConnection(username: String) {
        val user = intent.getParcelableExtra<UserResponse>(KEY_USER)
        val networkConnection = NetworkConnection(applicationContext)

        networkConnection.observe(this) { isConnected ->
            if (isConnected) {
                showLoading(true)
                val favorite = FavoriteEntity().apply {
                    login = username
                    id = intent.getIntExtra(KEY_ID, 0)
                    avatar_url = user?.avatarUrl
                }

                val detailViewModel: DetailViewModel by viewModels {
                    DetailViewModelFactory(username, application)
                }

                // Observe isLoading to show/hide progress bar
                detailViewModel.isLoading.observe(this@DetailActivity) {
                    showLoading(it)
                }

                // Observe detailUser to set user data
                detailViewModel.detailUser.observe(this@DetailActivity) { userResponse ->
                    if (userResponse != null) {
                        setData(userResponse)
                        setTabLayoutAdapter(userResponse)
                    }
                }

                // Observe favorite result from the database
                detailViewModel.getFavoriteById(favorite.id!!)
                    .observe(this@DetailActivity) { listFav ->
                        isFavorite = listFav.isNotEmpty()

                        binding.detailFabFavorite.imageTintList = if (listFav.isEmpty()) {
                            ColorStateList.valueOf(Color.rgb(255, 255, 255))
                        } else {
                            ColorStateList.valueOf(Color.rgb(247, 106, 123))
                        }
                    }

                // Set onClickListener for fabFavorite
                binding.detailFabFavorite.setOnClickListener {
                    if (isFavorite) {
                        detailViewModel.delete(favorite)
                        Toast.makeText(
                            this@DetailActivity,
                            "${favorite.login} HAS BEEN REMOVED FROM USER FAVORITES",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        detailViewModel.insert(favorite)
                        Toast.makeText(
                            this@DetailActivity,
                            "${favorite.login} WAS ADDED FROM USER FAVORITES",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            } else {
                // Hide detailDataLayout and show detailAnimationLayout when not connected
                binding.detailDataLayout.visibility = View.GONE
                binding.detailAnimationLayout.visibility = View.VISIBLE
            }
        }
    }
    private fun setTabLayoutAdapter(user: UserResponse) {
        val sectionPagerAdapter = SectionPagerAdapter(this@DetailActivity)
        sectionPagerAdapter.model = user
        binding.detailViewPager.adapter = sectionPagerAdapter
        TabLayoutMediator(binding.detailTabs, binding.detailViewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f

    }

    private fun setData(userResponse: UserResponse?) {
        if (userResponse != null) {
            with(binding) {
                detailDataLayout.visibility = View.VISIBLE
                detailImage.visibility = View.VISIBLE
                Glide.with(root)
                    .load(userResponse.avatarUrl)
                    .apply(
                        RequestOptions.placeholderOf(R.drawable.ic_loading)
                            .error(R.drawable.ic_error)
                    )
                    .circleCrop()
                    .into(binding.detailImage)
                detailName.visibility = View.VISIBLE
                detailUsername.visibility = View.VISIBLE
                detailName.text = userResponse.name
                detailUsername.text = userResponse.login
                if (userResponse.followers != null) {
                    detailFollowersValue.visibility = View.VISIBLE
                    detailFollowersValue.text = userResponse.followers
                } else {
                    detailFollowersValue.visibility = View.GONE
                }
                if (userResponse.followers != null) {
                    detailFollowers.visibility = View.VISIBLE
                } else {
                    detailFollowers.visibility = View.GONE
                }
                if (userResponse.following != null) {
                    detailFollowingValue.visibility = View.VISIBLE
                    detailFollowingValue.text = userResponse.following
                } else {
                    detailFollowingValue.visibility = View.GONE
                }
                if (userResponse.following != null) {
                    detailFollowing.visibility = View.VISIBLE
                } else {
                    detailFollowing.visibility = View.GONE
                }
            }
        } else {
            Log.i(TAG, "setData function is error")
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }

    companion object {
        const val KEY_USER = "user"
        private const val TAG = "DetailActivity"
        const val KEY_USERNAME = "username"
        const val KEY_ID = "extra id"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.fragment_one,
            R.string.fragment_two
        )
    }

}