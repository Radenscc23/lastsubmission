package com.example.githubuser.adapter

import com.example.githubuser.datasource.UserResponse

interface OnItemClickCallback {
    fun onItemClicked(user: UserResponse)
}